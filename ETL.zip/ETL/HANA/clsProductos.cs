﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using ETL.Model;
using ETL.PBI;
using Newtonsoft.Json;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;


namespace ETL.HANA
{
    class clsProductos
    {

    }
}
