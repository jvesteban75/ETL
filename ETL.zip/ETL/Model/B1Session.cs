﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ETL.Model
{
    public class B1Session
    {
        public string SessionId { get; set; }
        public string Version { get; set; }
        public string SessionTimeout { get; set; }
    }
}
